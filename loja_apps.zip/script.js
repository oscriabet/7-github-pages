document.querySelectorAll('.botao').forEach(button => {
    button.addEventListener('click', () => {
        alert("Ação realizada!");
    });
});